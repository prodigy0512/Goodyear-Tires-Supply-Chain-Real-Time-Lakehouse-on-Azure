Add an architecture diagram (draw.io / PPT / Excalidraw) and export as PNG into docs/diagrams/
